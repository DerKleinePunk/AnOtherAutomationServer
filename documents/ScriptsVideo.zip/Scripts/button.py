from pynput.keyboard import Key, Controller
import RPi.GPIO as GPIO
import time
import os

Keyboard = Controller()

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(26, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(22, GPIO.OUT)

while True:
    input_state = GPIO.input(18)
    if input_state == False:
        Keyboard.press(Key.alt)
        Keyboard.press(Key.tab)
        Keyboard.release(Key.alt)
        Keyboard.release(Key.tab)
        GPIO.output(22,GPIO.HIGH)
        time.sleep(.1)
        GPIO.output(22,GPIO.LOW)
        time.sleep(0.2)


    toggle = GPIO.input(26)
    if toggle == False:
        Keyboard.press(Key.right)
        Keyboard.release(Key.right)
        time.sleep(0.1)
        
