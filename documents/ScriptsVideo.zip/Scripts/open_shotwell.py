from pynput.keyboard import Key, Controller
import time
import os
Keyboard = Controller()

command = 'shotwell &'

time.sleep(15)

os.system(command)

time.sleep(10)

Keyboard.press(Key.f5)
Keyboard.release(Key.f5)
