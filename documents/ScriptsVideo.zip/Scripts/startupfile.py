import os
from pynput.mouse import Button, Controller
import time

mouse = Controller()

mouse.position = (1679, 1049)

command = 'chromium-browser --kiosk'

os.system(command)
